#ifndef dico_h
#define dico_h
#include <stdio.h>

int takeWord(char *takenWord);
int randomNumber(int numberMax);

#endif /* dico_h */
